/**
 * ┌─────────────────────────────────────────────────┐
 * │  Project: web-rainbow-server
 * │  File: index
 * │  Developer: kjlee
 * │  Created: 25. 8. 18.
 * │  Description: index 모듈
 * └─────────────────────────────────────────────────┘
 */

export * from './amr';
