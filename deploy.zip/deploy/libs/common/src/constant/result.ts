export const RESULT_SUCCESS = 'success';
export const RESULT_FAIL = 'fail';
export const RESULT_WORKING = 'working';
export const RESULT_IDLE = 'idle';
