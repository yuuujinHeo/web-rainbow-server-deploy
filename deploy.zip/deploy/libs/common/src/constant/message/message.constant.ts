/**
 * ┌─────────────────────────────────────────────────┐
 * │  Project: web-rainbow-server
 * │  File: message.constant
 * │  Developer: kjlee
 * │  Created: 25. 8. 12.
 * │  Description: message.constant 모듈
 * └─────────────────────────────────────────────────┘
 */

export const ERROR_MESSAGE = {
  // 사용자 관련 에러
  USER: {
    ID_REQUIRED: '사용자 아이디는 필수입니다.',
    NOT_FOUND: '사용자를 찾을 수 없습니다.',
    ALREADY_EXISTS: '이미 존재하는 사용자입니다.',
    INVALID_PASSWORD: '비밀번호가 올바르지 않습니다.',
  },

  // 로봇 관련 에러
  ROBOT: {
    SERIAL_REQUIRED: '로봇 시리얼은 필수입니다.',
    NOT_FOUND: '로봇을 찾을 수 없습니다.',
    ALREADY_EXISTS: '이미 존재하는 로봇입니다.',
  },

  // 인증 관련 에러
  AUTH: {
    TOKEN_REQUIRED: '인증 토큰이 필요합니다.',
    TOKEN_INVALID: '유효하지 않은 토큰입니다.',
    TOKEN_EXPIRED: '토큰이 만료되었습니다.',
    UNAUTHORIZED: '인증이 필요합니다.',
    ALREADY_EXISTS: '이미 존재하는 사용자입니다.',
  },

  // 코드 관련 에러
  CODE: {
    NOT_FOUND: '코드를 찾을 수 없습니다.',
    ALREADY_EXISTS: '이미 존재하는 코드입니다.',
  },

  // 소켓 관련 에러
  SOCKET: {
    NOT_FOUND: 'Socket정보를 찾을 수 없습니다.',
  },

  // 맵 관련 에러
  MAP: {
    NOT_FOUND: '맵을 찾을 수 없습니다.',
    INVALID_FORMAT: '올바르지 않은 맵 형식입니다.',
    SAVE_FAILED: '맵 저장에 실패했습니다.',
  },

  // 공통 에러
  COMMON: {
    BAD_REQUEST: '잘못된 요청입니다.',
    INTERNAL_SERVER_ERROR: '서버 내부 오류가 발생했습니다.',
    VALIDATION_FAILED: '유효성 검사에 실패했습니다.',
    FORBIDDEN: '권한이 없습니다.',
  },
} as const;

export const SUCCESS_MESSAGES = {
  USER: {
    CREATED: '사용자가 성공적으로 생성되었습니다.',
    UPDATED: '사용자 정보가 성공적으로 업데이트되었습니다.',
    DELETED: '사용자가 성공적으로 삭제되었습니다.',
  },

  MAP: {
    SAVED: '맵이 성공적으로 저장되었습니다.',
    LOADED: '맵이 성공적으로 로드되었습니다.',
    UPDATED: '맵이 성공적으로 업데이트되었습니다.',
  },
} as const;
