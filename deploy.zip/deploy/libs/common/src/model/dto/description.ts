export enum FrsDescription {
  COMMAND = '',
  ROBOT_SERIAL = '로봇시리얼 uuid. 로봇에 저장된 고유한 번호로 FRS에 등록 시 사용됨.',
  ROBOT_NAME = '로봇 이름. 초기에 robotSerial과 동일한 값으로 설정되며 변경 가능',
}
