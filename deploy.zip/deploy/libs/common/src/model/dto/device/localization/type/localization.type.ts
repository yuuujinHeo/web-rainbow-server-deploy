export enum LocalizationCommand {
  setInit = 'init',
  semiAutoInit = 'semiautoinit',
  randomInit = 'randominit',
  autoInit = 'autoinit',
  start = 'start',
  stop = 'stop',
}
