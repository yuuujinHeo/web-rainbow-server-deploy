export enum client_description {
  TOPIC = '구독/구독해제 할 토픽명을 입력하세요.',
}
