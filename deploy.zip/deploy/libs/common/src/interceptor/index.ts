export * from './grpc.interceptor';
